
var totalPagesLocal = 0;
var pageLocal = 1;

$(document).ready(function(){
	
	// nếu nhấn nút hiển thị trong pagination
	$('button#pagination').click(function(){
		pagination(0);
	});
	
	// su kien nhan nut next previous 
	$('button.previous').click(function(){
		pagination(-1);
	});
	
	$('button.next').click(function(){
		pagination(1);
	});
})

function setInit(page, rowPerPage, totalPages){
	pageLocal = page;
	totalPagesLocal = totalPages;
	if(totalPages==1){
		$('button.previous, button.next').prop('disabled', true);
		$('i.fa-arrow-right, i.fa-arrow-left').addClass('disabled');
	}else{
		if(page==1 && totalPages>1){
			$('button.previous').prop('disabled', true);
			$('i.fa-arrow-left').addClass('disabled');
		}
		if(page==totalPages){
			$('button.next').prop('disabled', true);
			$('i.fa-arrow-right').addClass('disabled');
		}
	}
}

function pagination(plus){
	var page = $('input#page').val();
	var rowPerPage = $('select#rowPerPage').val();
	if(page>0 && page<=totalPagesLocal){
		$('input[name="page"]').val(parseInt(page)+plus);
		$('input[name="rowPerPage"]').val(rowPerPage);
		$('button.btnS').onclick();
	}else{
		$('input#page').val(pageLocal).css('border-color','red');
		
		setTimeout(function(){
			$('input#page').css('border-color','#2266aa');
		}, 500);
		
	}
}

function exportFile(){
	var teamID = $('input#TID').val();
	var seasonID = $('input#SID').val();
	window.open("download.do?teamID="+teamID+"&seasonID="+seasonID);
}